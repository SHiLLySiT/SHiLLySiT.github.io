********************
Voyage of Discovery
by Alex Larioza
********************
1 Introduction
2 Controls
	2.1 Movement
	2.2 Commands
3 Interface
4 Gameplay
5 Tips

1 Introduction
Voyage of Discovery is my entry into the 19th Ludum Dare competition which has the theme of
'discovery'. I went with the rougelike genre in one hand and colonization in the other; this is
the result. Like most rouge-likes, this game can be impossible at times. (Such as spawning next to pirates.)
Most of this intentional, but there is occasionally a hicup in the map generator that causes little
quirks here and there. Nonetheless, I've done my best to polish the game the best I could before
the 48hour deadline. So good luck and happy exploring!]

For more information, visit my blog at:
http://lonelypixel.wordpress.com

2 Controls
-Sorry all the controls are hardcoded, didn't have the time to implement customization. I will if I
decide to create a post-compo edition.

2.1 Movement
(Standard rouge-likekeys)
Numpad keys 1-9
-Each key moves you in the respective direction
-You can't move onto islands, but you can move off
	-This is to compensate for a bug.(Sometimes you spawn on an island.)

2.2 Commands
-[ESC] Quits the game at ANYTIME
-[F4] to change from windowed to fullscreen
-[F9] to take screen shots (Saved in same folder as exe)
-You can't move when a command is active
-All commands with the exception of [b]uying and [i]information take a step

[q]uit
	-Quits current command
[i]nformation
	-Gives information about the tile
[c]olonize
	-Colonizes an island
	-Must be islands with a village on them (4x4)
	-Costs 10 Supply
	-After colonizing 3 islands, you are given the option to gain a stat or not
		-Choose yes and you can pick from four:
			-ATK Increases attack by one point
			-FOV Increase Field of Vision by 16cell radius
			-Hull Increases max hull strength (Also heals you to max)
			-Supply Increases max supply
		-Choose no and you've made your life harder
[b]uy
	-Buys supplies from a colonized island
	-Buys max to fill your supply
		-If you don't have enough for the maximum, it will buy how much you can afford.
	-Check colony with [i]nformation to check the prices
[r]epair
	-Repairs your ship with wood from a forest
		-Forests are located on islands with trees
	-You dont have to select the tile with the tree, but it has to be the same island.
[e]xplore
	-Explores islands to uncover treasure, supplies, explorers, or nothing.
	-Costs supplies
	-Check the islands with [i]nformation to check how many supplies it will consume
[a]ttack
	-Attacks a pirateship
	-You must have at least 1ATK point to attack
	-Hit/Miss percentage is random
		-Pirates are are significatly more accurate than you

3 Interface
-The left side
-In order from top to bottom
(Visual) Hull Strength bar 
(Text) Hull Strength/Hull Max
(Visual) Remainin Supply bar 
(Text) Remaining Supply/Supply Max
Islands colonized/Islands in world 
Percent of world explored (100% IS NOT required to win)
$ Current gold balance
ATK points
FOV range
Current Explorer
Explorer perk (Only shows when you have an explorer on board)
Score
-Bottom bar
A log of events

4. Gameplay
Like othe rouge-likes, nothing happens until YOU preform an action. The game is also grid based so
movement is limited to 8 directions (See controls). Events and information are shown in the bottom 
bar and stats are shown on the right bar. The ultimate goal is to colonize all of the islands with
villages. Until you do, you must plan your movements because each steps uses 1 supply. Supplies can
be replenished at colonies with the buy command at the cost of gold. Gold is obtained by colonizing
new islands and exploring the smaller islands throughout the map.
 
You also must watch out for pirates. Pirates are randomly placed throughout the world and will wander 
aimlessly until you are in their range. When that happens, they will follow you and attack your ship. 
If you manage to destroy one, it will drop a treasure chest that contains gold and supplies. Simply 
move into the tile to collect the chest. Skirmishes will often lead to hull damage; repair your ship with
wood from forests on islands.

There are three Explorers that you can meet when exploring islands, though the chance is small. Michelle gives defense
against pirate attacks, marco makes supplies cheaper when buying from colonies, and cortez increases the chance of finding
gold when exploring. When you do find one, you are given the option to allow them to come aboard or you can leave 
them behind. If you choose yes and you already have another Explorer aboard your ship, the previous Explorer will be 
replaced with the new one.


The Goal: 
	to survive and colonize all of the villages in the current world.
		(shown on left bar under exploration)
Losing Conditions: 
	You run out of supplies
	Your hull strength reaches 0

5. Tips
-Colonize an island as soon as you can, otherwise you have no sure place to replenish supplies
-Check colonies with [i]nformation to see who as the best price on supplies
	-If you can, always go to the cheapest one to save gold
-Exploring islands is a must
-Avoid pirates until you have a high enough ATK level
	-Otherwise it usually ends in destruction
	-Or a waste of supplies
-Sail between islands when pirates are trailing you
	-They don't like difficult prey
-Fight pirates near islands with forests so you can repair when needed
-Survival is not guarenteed















